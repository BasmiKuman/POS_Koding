// Mobile POS Application
class MobilePOSApp {
    constructor() {
        this.currentUser = null;
        this.currentPage = 'dashboard';
        this.cart = [];
        this.products = [];
        this.transactions = [];
        this.isOnline = navigator.onLine;
        this.apiBase = window.location.origin;
        
        this.init();
    }

    async init() {
        // Show loading screen
        this.showLoading();
        
        // Initialize event listeners
        this.initEventListeners();
        
        // Check authentication
        await this.checkAuth();
        
        // Initialize PWA features
        this.initPWA();
        
        // Initialize offline support
        this.initOfflineSupport();
        
        // Hide loading screen
        setTimeout(() => this.hideLoading(), 1000);
    }

    initEventListeners() {
        // Login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // Demo account buttons
        document.querySelectorAll('.demo-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleDemoLogin(e));
        });

        // Menu toggle
        const menuBtn = document.getElementById('menuBtn');
        if (menuBtn) {
            menuBtn.addEventListener('click', () => this.toggleMenu());
        }

        // Navigation
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', (e) => this.handleNavigation(e));
        });

        // Quick actions
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleQuickAction(e));
        });

        // Logout
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.handleLogout());
        }

        // Sync button
        const syncBtn = document.getElementById('syncBtn');
        if (syncBtn) {
            syncBtn.addEventListener('click', () => this.syncData());
        }

        // Online/offline events
        window.addEventListener('online', () => this.handleOnlineStatus(true));
        window.addEventListener('offline', () => this.handleOnlineStatus(false));

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            const sideMenu = document.getElementById('sideMenu');
            const menuBtn = document.getElementById('menuBtn');
            
            if (sideMenu && !sideMenu.contains(e.target) && !menuBtn.contains(e.target)) {
                sideMenu.classList.remove('open');
            }
        });
    }

    showLoading() {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            loadingScreen.style.display = 'flex';
        }
    }

    hideLoading() {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            loadingScreen.style.display = 'none';
        }
    }

    async checkAuth() {
        const token = localStorage.getItem('pos_token');
        const userData = localStorage.getItem('pos_user');
        
        if (token && userData) {
            try {
                this.currentUser = JSON.parse(userData);
                await this.loadUserData();
                this.showMainApp();
            } catch (error) {
                console.error('Auth check failed:', error);
                this.showLoginScreen();
            }
        } else {
            this.showLoginScreen();
        }
    }

    showLoginScreen() {
        document.getElementById('loginScreen').classList.add('active');
        document.getElementById('mainApp').classList.remove('active');
    }

    showMainApp() {
        document.getElementById('loginScreen').classList.remove('active');
        document.getElementById('mainApp').classList.add('active');
        
        // Update user info
        const userName = document.getElementById('userName');
        if (userName && this.currentUser) {
            userName.textContent = this.currentUser.name || this.currentUser.email;
        }
        
        // Load initial data
        this.loadDashboardData();
        this.navigateToPage('dashboard');
    }

    async handleLogin(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        try {
            const response = await this.apiCall('/api/auth/login', {
                method: 'POST',
                body: JSON.stringify({ email, password })
            });
            
            if (response.success) {
                localStorage.setItem('pos_token', response.token);
                localStorage.setItem('pos_user', JSON.stringify(response.user));
                this.currentUser = response.user;
                this.showMainApp();
            } else {
                this.showError('Invalid credentials');
            }
        } catch (error) {
            console.error('Login failed:', error);
            this.showError('Login failed. Please try again.');
        }
    }

    handleDemoLogin(e) {
        const email = e.target.dataset.email;
        const password = e.target.dataset.password;
        
        document.getElementById('email').value = email;
        document.getElementById('password').value = password;
        
        // Auto-submit the form
        document.getElementById('loginForm').dispatchEvent(new Event('submit'));
    }

    handleLogout() {
        localStorage.removeItem('pos_token');
        localStorage.removeItem('pos_user');
        this.currentUser = null;
        this.cart = [];
        this.showLoginScreen();
    }

    toggleMenu() {
        const sideMenu = document.getElementById('sideMenu');
        if (sideMenu) {
            sideMenu.classList.toggle('open');
        }
    }

    handleNavigation(e) {
        e.preventDefault();
        const page = e.target.closest('.menu-item').dataset.page;
        this.navigateToPage(page);
        
        // Close menu on mobile
        const sideMenu = document.getElementById('sideMenu');
        if (sideMenu) {
            sideMenu.classList.remove('open');
        }
    }

    handleQuickAction(e) {
        const page = e.target.closest('.action-btn').dataset.page;
        this.navigateToPage(page);
    }

    navigateToPage(page) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        
        // Show target page
        const targetPage = document.getElementById(`${page}Page`);
        if (targetPage) {
            targetPage.classList.add('active');
        }
        
        // Update menu active state
        document.querySelectorAll('.menu-item').forEach(item => {
            item.classList.remove('active');
        });
        
        const activeMenuItem = document.querySelector(`[data-page="${page}"]`);
        if (activeMenuItem) {
            activeMenuItem.classList.add('active');
        }
        
        // Update page title
        const pageTitle = document.getElementById('pageTitle');
        if (pageTitle) {
            const titles = {
                dashboard: 'Dashboard',
                pos: 'Point of Sale',
                products: 'Products',
                transactions: 'Transactions',
                reports: 'Reports',
                settings: 'Settings'
            };
            pageTitle.textContent = titles[page] || 'POS Mobile';
        }
        
        this.currentPage = page;
        
        // Load page-specific data
        this.loadPageData(page);
    }

    async loadPageData(page) {
        switch (page) {
            case 'dashboard':
                await this.loadDashboardData();
                break;
            case 'pos':
                await this.loadPOSData();
                break;
            case 'products':
                await this.loadProductsData();
                break;
            case 'transactions':
                await this.loadTransactionsData();
                break;
            case 'reports':
                await this.loadReportsData();
                break;
            case 'settings':
                this.loadSettingsData();
                break;
        }
    }

    async loadUserData() {
        try {
            // Load user-specific data
            await Promise.all([
                this.loadProducts(),
                this.loadRecentTransactions()
            ]);
        } catch (error) {
            console.error('Failed to load user data:', error);
        }
    }

    async loadDashboardData() {
        try {
            const [statsResponse, transactionsResponse] = await Promise.all([
                this.apiCall('/api/dashboard/stats'),
                this.apiCall('/api/transactions/recent')
            ]);
            
            if (statsResponse.success) {
                this.updateDashboardStats(statsResponse.data);
            }
            
            if (transactionsResponse.success) {
                this.updateRecentTransactions(transactionsResponse.data);
            }
        } catch (error) {
            console.error('Failed to load dashboard data:', error);
            this.loadOfflineDashboardData();
        }
    }

    updateDashboardStats(stats) {
        const elements = {
            todaySales: document.getElementById('todaySales'),
            todayTransactions: document.getElementById('todayTransactions'),
            totalProducts: document.getElementById('totalProducts'),
            totalCustomers: document.getElementById('totalCustomers')
        };
        
        if (elements.todaySales) elements.todaySales.textContent = this.formatCurrency(stats.todaySales || 0);
        if (elements.todayTransactions) elements.todayTransactions.textContent = stats.todayTransactions || 0;
        if (elements.totalProducts) elements.totalProducts.textContent = stats.totalProducts || 0;
        if (elements.totalCustomers) elements.totalCustomers.textContent = stats.totalCustomers || 0;
    }

    updateRecentTransactions(transactions) {
        const container = document.getElementById('recentTransactionsList');
        if (!container) return;
        
        if (transactions.length === 0) {
            container.innerHTML = '<p class="text-center">No recent transactions</p>';
            return;
        }
        
        container.innerHTML = transactions.map(transaction => `
            <div class="transaction-item">
                <div class="transaction-header">
                    <span class="transaction-id">#${transaction.id}</span>
                    <span class="transaction-amount">${this.formatCurrency(transaction.total)}</span>
                </div>
                <div class="transaction-details">
                    ${new Date(transaction.created_at).toLocaleString()} • ${transaction.items_count} items
                </div>
            </div>
        `).join('');
    }

    async loadPOSData() {
        await this.loadProducts();
        this.renderProductGrid();
        this.updateCartDisplay();
    }

    async loadProducts() {
        try {
            const response = await this.apiCall('/api/products');
            if (response.success) {
                this.products = response.data;
                this.saveToOfflineStorage('products', this.products);
            }
        } catch (error) {
            console.error('Failed to load products:', error);
            this.products = this.getFromOfflineStorage('products') || [];
        }
    }

    renderProductGrid() {
        const container = document.getElementById('productGrid');
        if (!container) return;
        
        const filteredProducts = this.filterProducts();
        
        container.innerHTML = filteredProducts.map(product => `
            <div class="product-card" onclick="app.addToCart(${product.id})">
                <img src="${product.image || '/images/product-placeholder.png'}" alt="${product.name}">
                <h4>${product.name}</h4>
                <p class="price">${this.formatCurrency(product.price)}</p>
            </div>
        `).join('');
    }

    filterProducts() {
        // Implement product filtering logic
        return this.products;
    }

    addToCart(productId) {
        const product = this.products.find(p => p.id === productId);
        if (!product) return;
        
        const existingItem = this.cart.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.cart.push({
                ...product,
                quantity: 1
            });
        }
        
        this.updateCartDisplay();
        this.saveCartToStorage();
    }

    updateCartDisplay() {
        const container = document.getElementById('cartItems');
        const subtotalEl = document.getElementById('subtotal');
        const taxEl = document.getElementById('tax');
        const totalEl = document.getElementById('total');
        const checkoutBtn = document.getElementById('checkoutBtn');
        
        if (!container) return;
        
        if (this.cart.length === 0) {
            container.innerHTML = '<p class="text-center">Cart is empty</p>';
            if (subtotalEl) subtotalEl.textContent = '$0.00';
            if (taxEl) taxEl.textContent = '$0.00';
            if (totalEl) totalEl.textContent = '$0.00';
            if (checkoutBtn) checkoutBtn.disabled = true;
            return;
        }
        
        container.innerHTML = this.cart.map(item => `
            <div class="cart-item">
                <div class="cart-item-info">
                    <h5>${item.name}</h5>
                    <p>${this.formatCurrency(item.price)} each</p>
                </div>
                <div class="quantity-controls">
                    <button class="quantity-btn" onclick="app.updateCartQuantity(${item.id}, -1)">-</button>
                    <input type="number" class="quantity-input" value="${item.quantity}" min="1" 
                           onchange="app.setCartQuantity(${item.id}, this.value)">
                    <button class="quantity-btn" onclick="app.updateCartQuantity(${item.id}, 1)">+</button>
                </div>
            </div>
        `).join('');
        
        const subtotal = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const tax = subtotal * 0.1; // 10% tax
        const total = subtotal + tax;
        
        if (subtotalEl) subtotalEl.textContent = this.formatCurrency(subtotal);
        if (taxEl) taxEl.textContent = this.formatCurrency(tax);
        if (totalEl) totalEl.textContent = this.formatCurrency(total);
        if (checkoutBtn) checkoutBtn.disabled = false;
    }

    updateCartQuantity(productId, change) {
        const item = this.cart.find(item => item.id === productId);
        if (!item) return;
        
        item.quantity += change;
        
        if (item.quantity <= 0) {
            this.cart = this.cart.filter(item => item.id !== productId);
        }
        
        this.updateCartDisplay();
        this.saveCartToStorage();
    }

    setCartQuantity(productId, quantity) {
        const item = this.cart.find(item => item.id === productId);
        if (!item) return;
        
        const newQuantity = parseInt(quantity);
        if (newQuantity <= 0) {
            this.cart = this.cart.filter(item => item.id !== productId);
        } else {
            item.quantity = newQuantity;
        }
        
        this.updateCartDisplay();
        this.saveCartToStorage();
    }

    clearCart() {
        this.cart = [];
        this.updateCartDisplay();
        this.saveCartToStorage();
    }

    async loadProductsData() {
        await this.loadProducts();
        this.renderProductsList();
    }

    renderProductsList() {
        const container = document.getElementById('productsList');
        if (!container) return;
        
        container.innerHTML = this.products.map(product => `
            <div class="product-item">
                <img src="${product.image || '/images/product-placeholder.png'}" alt="${product.name}">
                <div class="product-details">
                    <h4>${product.name}</h4>
                    <p>Category: ${product.category}</p>
                    <p>Stock: ${product.stock}</p>
                    <div class="product-price">${this.formatCurrency(product.price)}</div>
                </div>
                <div class="product-actions">
                    <button class="edit-btn" onclick="app.editProduct(${product.id})">Edit</button>
                    <button class="delete-btn" onclick="app.deleteProduct(${product.id})">Delete</button>
                </div>
            </div>
        `).join('');
    }

    async loadTransactionsData() {
        try {
            const response = await this.apiCall('/api/transactions');
            if (response.success) {
                this.transactions = response.data;
                this.renderTransactionsList();
            }
        } catch (error) {
            console.error('Failed to load transactions:', error);
            this.transactions = this.getFromOfflineStorage('transactions') || [];
            this.renderTransactionsList();
        }
    }

    renderTransactionsList() {
        const container = document.getElementById('transactionsList');
        if (!container) return;
        
        if (this.transactions.length === 0) {
            container.innerHTML = '<p class="text-center">No transactions found</p>';
            return;
        }
        
        container.innerHTML = this.transactions.map(transaction => `
            <div class="transaction-item">
                <div class="transaction-header">
                    <span class="transaction-id">#${transaction.id}</span>
                    <span class="transaction-amount">${this.formatCurrency(transaction.total)}</span>
                </div>
                <div class="transaction-details">
                    ${new Date(transaction.created_at).toLocaleString()} • 
                    ${transaction.payment_method} • 
                    ${transaction.items_count} items
                </div>
            </div>
        `).join('');
    }

    async loadReportsData() {
        try {
            const response = await this.apiCall('/api/reports/summary');
            if (response.success) {
                this.updateReportsDisplay(response.data);
            }
        } catch (error) {
            console.error('Failed to load reports:', error);
        }
    }

    updateReportsDisplay(data) {
        const elements = {
            reportTodaySales: document.getElementById('reportTodaySales'),
            reportWeekSales: document.getElementById('reportWeekSales'),
            reportMonthSales: document.getElementById('reportMonthSales')
        };
        
        if (elements.reportTodaySales) elements.reportTodaySales.textContent = this.formatCurrency(data.todaySales || 0);
        if (elements.reportWeekSales) elements.reportWeekSales.textContent = this.formatCurrency(data.weekSales || 0);
        if (elements.reportMonthSales) elements.reportMonthSales.textContent = this.formatCurrency(data.monthSales || 0);
        
        // Update top products
        const topProductsList = document.getElementById('topProductsList');
        if (topProductsList && data.topProducts) {
            topProductsList.innerHTML = data.topProducts.map(product => `
                <div class="top-product">
                    <span>${product.name}</span>
                    <span>${product.sold_count} sold</span>
                </div>
            `).join('');
        }
    }

    loadSettingsData() {
        // Load settings from localStorage
        const offlineMode = localStorage.getItem('pos_offline_mode') === 'true';
        const notifications = localStorage.getItem('pos_notifications') !== 'false';
        
        const offlineModeCheckbox = document.getElementById('offlineMode');
        const notificationsCheckbox = document.getElementById('notifications');
        
        if (offlineModeCheckbox) offlineModeCheckbox.checked = offlineMode;
        if (notificationsCheckbox) notificationsCheckbox.checked = notifications;
    }

    async syncData() {
        if (!this.isOnline) {
            this.showError('Cannot sync while offline');
            return;
        }
        
        const syncBtn = document.getElementById('syncBtn');
        if (syncBtn) {
            syncBtn.classList.add('syncing');
        }
        
        try {
            // Sync offline transactions
            await this.syncOfflineTransactions();
            
            // Reload data
            await this.loadUserData();
            await this.loadPageData(this.currentPage);
            
            this.showSuccess('Data synced successfully');
        } catch (error) {
            console.error('Sync failed:', error);
            this.showError('Sync failed');
        } finally {
            if (syncBtn) {
                syncBtn.classList.remove('syncing');
            }
        }
    }

    async syncOfflineTransactions() {
        const offlineTransactions = this.getFromOfflineStorage('offline_transactions') || [];
        
        for (const transaction of offlineTransactions) {
            try {
                await this.apiCall('/api/transactions', {
                    method: 'POST',
                    body: JSON.stringify(transaction)
                });
            } catch (error) {
                console.error('Failed to sync transaction:', error);
            }
        }
        
        // Clear offline transactions after successful sync
        this.removeFromOfflineStorage('offline_transactions');
    }

    handleOnlineStatus(isOnline) {
        this.isOnline = isOnline;
        const indicator = document.getElementById('offlineIndicator');
        
        if (indicator) {
            if (isOnline) {
                indicator.classList.add('hidden');
                // Auto-sync when coming back online
                this.syncData();
            } else {
                indicator.classList.remove('hidden');
            }
        }
    }

    async apiCall(endpoint, options = {}) {
        const token = localStorage.getItem('pos_token');
        
        const defaultOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                ...(token && { 'Authorization': `Bearer ${token}` })
            }
        };
        
        const response = await fetch(`${this.apiBase}${endpoint}`, {
            ...defaultOptions,
            ...options,
            headers: {
                ...defaultOptions.headers,
                ...options.headers
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    }

    // Offline storage methods
    saveToOfflineStorage(key, data) {
        try {
            localStorage.setItem(`pos_offline_${key}`, JSON.stringify(data));
        } catch (error) {
            console.error('Failed to save to offline storage:', error);
        }
    }

    getFromOfflineStorage(key) {
        try {
            const data = localStorage.getItem(`pos_offline_${key}`);
            return data ? JSON.parse(data) : null;
        } catch (error) {
            console.error('Failed to get from offline storage:', error);
            return null;
        }
    }

    removeFromOfflineStorage(key) {
        try {
            localStorage.removeItem(`pos_offline_${key}`);
        } catch (error) {
            console.error('Failed to remove from offline storage:', error);
        }
    }

    saveCartToStorage() {
        this.saveToOfflineStorage('cart', this.cart);
    }

    loadCartFromStorage() {
        this.cart = this.getFromOfflineStorage('cart') || [];
    }

    loadOfflineDashboardData() {
        // Load cached dashboard data
        const cachedStats = this.getFromOfflineStorage('dashboard_stats');
        const cachedTransactions = this.getFromOfflineStorage('recent_transactions');
        
        if (cachedStats) this.updateDashboardStats(cachedStats);
        if (cachedTransactions) this.updateRecentTransactions(cachedTransactions);
    }

    // PWA methods
    initPWA() {
        // Install prompt
        let deferredPrompt;
        
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            this.showInstallPrompt();
        });
        
        const installBtn = document.getElementById('installBtn');
        const dismissBtn = document.getElementById('dismissBtn');
        
        if (installBtn) {
            installBtn.addEventListener('click', async () => {
                if (deferredPrompt) {
                    deferredPrompt.prompt();
                    const { outcome } = await deferredPrompt.userChoice;
                    console.log(`User response to the install prompt: ${outcome}`);
                    deferredPrompt = null;
                }
                this.hideInstallPrompt();
            });
        }
        
        if (dismissBtn) {
            dismissBtn.addEventListener('click', () => {
                this.hideInstallPrompt();
            });
        }
    }

    showInstallPrompt() {
        const prompt = document.getElementById('installPrompt');
        if (prompt) {
            prompt.classList.remove('hidden');
        }
    }

    hideInstallPrompt() {
        const prompt = document.getElementById('installPrompt');
        if (prompt) {
            prompt.classList.add('hidden');
        }
    }

    initOfflineSupport() {
        // Load cart from storage
        this.loadCartFromStorage();
        
        // Set initial online status
        this.handleOnlineStatus(navigator.onLine);
    }

    // Utility methods
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    }

    showError(message) {
        // Simple error display - can be enhanced with toast notifications
        alert(`Error: ${message}`);
    }

    showSuccess(message) {
        // Simple success display - can be enhanced with toast notifications
        alert(`Success: ${message}`);
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new MobilePOSApp();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MobilePOSApp;
}
