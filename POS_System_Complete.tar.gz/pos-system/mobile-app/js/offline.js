// Offline Data Management
class OfflineManager {
    constructor() {
        this.dbName = 'POSOfflineDB';
        this.dbVersion = 1;
        this.db = null;
        
        this.init();
    }

    async init() {
        await this.openDatabase();
        this.setupOnlineListener();
    }

    async openDatabase() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve(this.db);
            };
            
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Create stores
                this.createStores(db);
            };
        });
    }

    createStores(db) {
        // Products store
        if (!db.objectStoreNames.contains('products')) {
            const productsStore = db.createObjectStore('products', { keyPath: 'id' });
            productsStore.createIndex('category', 'category', { unique: false });
            productsStore.createIndex('name', 'name', { unique: false });
        }

        // Transactions store
        if (!db.objectStoreNames.contains('transactions')) {
            const transactionsStore = db.createObjectStore('transactions', { keyPath: 'id', autoIncrement: true });
            transactionsStore.createIndex('date', 'created_at', { unique: false });
            transactionsStore.createIndex('synced', 'synced', { unique: false });
        }

        // Offline transactions store
        if (!db.objectStoreNames.contains('offline_transactions')) {
            const offlineStore = db.createObjectStore('offline_transactions', { keyPath: 'offline_id', autoIncrement: true });
            offlineStore.createIndex('synced', 'synced', { unique: false });
        }

        // Categories store
        if (!db.objectStoreNames.contains('categories')) {
            db.createObjectStore('categories', { keyPath: 'id' });
        }

        // Settings store
        if (!db.objectStoreNames.contains('settings')) {
            db.createObjectStore('settings', { keyPath: 'key' });
        }
    }

    // Generic database operations
    async add(storeName, data) {
        const transaction = this.db.transaction([storeName], 'readwrite');
        const store = transaction.objectStore(storeName);
        return store.add(data);
    }

    async put(storeName, data) {
        const transaction = this.db.transaction([storeName], 'readwrite');
        const store = transaction.objectStore(storeName);
        return store.put(data);
    }

    async get(storeName, key) {
        const transaction = this.db.transaction([storeName], 'readonly');
        const store = transaction.objectStore(storeName);
        return new Promise((resolve, reject) => {
            const request = store.get(key);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getAll(storeName) {
        const transaction = this.db.transaction([storeName], 'readonly');
        const store = transaction.objectStore(storeName);
        return new Promise((resolve, reject) => {
            const request = store.getAll();
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async delete(storeName, key) {
        const transaction = this.db.transaction([storeName], 'readwrite');
        const store = transaction.objectStore(storeName);
        return store.delete(key);
    }

    async clear(storeName) {
        const transaction = this.db.transaction([storeName], 'readwrite');
        const store = transaction.objectStore(storeName);
        return store.clear();
    }

    // Product operations
    async saveProducts(products) {
        const transaction = this.db.transaction(['products'], 'readwrite');
        const store = transaction.objectStore('products');
        
        for (const product of products) {
            store.put(product);
        }
        
        return new Promise((resolve, reject) => {
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
        });
    }

    async getProducts() {
        return this.getAll('products');
    }

    async getProductsByCategory(category) {
        const transaction = this.db.transaction(['products'], 'readonly');
        const store = transaction.objectStore('products');
        const index = store.index('category');
        
        return new Promise((resolve, reject) => {
            const request = index.getAll(category);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // Transaction operations
    async saveTransaction(transaction) {
        const offlineTransaction = {
            ...transaction,
            offline_id: Date.now(),
            created_offline: new Date().toISOString(),
            synced: false
        };
        
        return this.add('offline_transactions', offlineTransaction);
    }

    async getOfflineTransactions() {
        const transaction = this.db.transaction(['offline_transactions'], 'readonly');
        const store = transaction.objectStore('offline_transactions');
        const index = store.index('synced');
        
        return new Promise((resolve, reject) => {
            const request = index.getAll(false);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async markTransactionSynced(offlineId) {
        const transaction = await this.get('offline_transactions', offlineId);
        if (transaction) {
            transaction.synced = true;
            transaction.synced_at = new Date().toISOString();
            return this.put('offline_transactions', transaction);
        }
    }

    // Settings operations
    async saveSetting(key, value) {
        return this.put('settings', { key, value });
    }

    async getSetting(key) {
        const setting = await this.get('settings', key);
        return setting ? setting.value : null;
    }

    // Sync operations
    async syncWithServer() {
        if (!navigator.onLine) {
            throw new Error('Cannot sync while offline');
        }

        try {
            // Sync offline transactions
            await this.syncOfflineTransactions();
            
            // Fetch latest data from server
            await this.fetchLatestData();
            
            console.log('Sync completed successfully');
            return true;
        } catch (error) {
            console.error('Sync failed:', error);
            throw error;
        }
    }

    async syncOfflineTransactions() {
        const offlineTransactions = await this.getOfflineTransactions();
        
        for (const transaction of offlineTransactions) {
            try {
                const response = await fetch('/api/transactions', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${localStorage.getItem('pos_token')}`
                    },
                    body: JSON.stringify({
                        items: transaction.items,
                        total: transaction.total,
                        payment_method: transaction.payment_method,
                        amount_received: transaction.amount_received
                    })
                });
                
                if (response.ok) {
                    await this.markTransactionSynced(transaction.offline_id);
                }
            } catch (error) {
                console.error('Failed to sync transaction:', error);
            }
        }
    }

    async fetchLatestData() {
        try {
            // Fetch products
            const productsResponse = await fetch('/api/products', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('pos_token')}`
                }
            });
            
            if (productsResponse.ok) {
                const productsData = await productsResponse.json();
                if (productsData.success) {
                    await this.saveProducts(productsData.data);
                }
            }
            
            // Fetch categories
            const categoriesResponse = await fetch('/api/categories', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('pos_token')}`
                }
            });
            
            if (categoriesResponse.ok) {
                const categoriesData = await categoriesResponse.json();
                if (categoriesData.success) {
                    await this.saveCategories(categoriesData.data);
                }
            }
        } catch (error) {
            console.error('Failed to fetch latest data:', error);
        }
    }

    async saveCategories(categories) {
        const transaction = this.db.transaction(['categories'], 'readwrite');
        const store = transaction.objectStore('categories');
        
        for (const category of categories) {
            store.put(category);
        }
        
        return new Promise((resolve, reject) => {
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
        });
    }

    async getCategories() {
        return this.getAll('categories');
    }

    // Online status handling
    setupOnlineListener() {
        window.addEventListener('online', () => {
            console.log('Back online - attempting to sync');
            this.syncWithServer().catch(console.error);
        });

        window.addEventListener('offline', () => {
            console.log('Gone offline - switching to offline mode');
        });
    }

    // Data export/import
    async exportData() {
        const data = {
            products: await this.getProducts(),
            transactions: await this.getAll('offline_transactions'),
            categories: await this.getCategories(),
            settings: await this.getAll('settings'),
            exported_at: new Date().toISOString()
        };
        
        return data;
    }

    async importData(data) {
        if (data.products) await this.saveProducts(data.products);
        if (data.categories) await this.saveCategories(data.categories);
        if (data.settings) {
            for (const setting of data.settings) {
                await this.put('settings', setting);
            }
        }
    }

    // Clear all offline data
    async clearAllData() {
        const stores = ['products', 'transactions', 'offline_transactions', 'categories', 'settings'];
        
        for (const storeName of stores) {
            await this.clear(storeName);
        }
    }

    // Get storage usage
    async getStorageUsage() {
        if ('storage' in navigator && 'estimate' in navigator.storage) {
            return navigator.storage.estimate();
        }
        return null;
    }
}

// Initialize offline manager
const offlineManager = new OfflineManager();

// Export for global use
window.offlineManager = offlineManager;
