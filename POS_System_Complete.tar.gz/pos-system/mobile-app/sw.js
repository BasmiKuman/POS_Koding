// Service Worker for POS Mobile PWA
const CACHE_NAME = 'pos-mobile-v1.0.0';
const API_CACHE_NAME = 'pos-api-v1.0.0';

// Files to cache for offline functionality
const STATIC_CACHE_FILES = [
    '/mobile-app/',
    '/mobile-app/index.html',
    '/mobile-app/manifest.json',
    '/mobile-app/css/mobile.css',
    '/mobile-app/js/app.js',
    '/mobile-app/js/auth.js',
    '/mobile-app/js/pos.js',
    '/mobile-app/js/products.js',
    '/mobile-app/js/transactions.js',
    '/mobile-app/js/reports.js',
    '/mobile-app/js/offline.js',
    '/mobile-app/js/pwa.js',
    '/mobile-app/images/icon-192x192.png',
    '/mobile-app/images/icon-512x512.png',
    // External resources
    'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'
];

// API endpoints to cache
const API_CACHE_PATTERNS = [
    /\/api\/products/,
    /\/api\/categories/,
    /\/api\/dashboard\/stats/,
    /\/api\/transactions\/recent/
];

// Install event - cache static files
self.addEventListener('install', (event) => {
    console.log('Service Worker: Installing...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                console.log('Service Worker: Caching static files');
                return cache.addAll(STATIC_CACHE_FILES.map(url => {
                    // Handle external URLs
                    if (url.startsWith('http')) {
                        return new Request(url, { mode: 'cors' });
                    }
                    return url;
                }));
            })
            .catch((error) => {
                console.error('Service Worker: Cache installation failed:', error);
            })
    );
    
    // Force the waiting service worker to become the active service worker
    self.skipWaiting();
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
    console.log('Service Worker: Activating...');
    
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (cacheName !== CACHE_NAME && cacheName !== API_CACHE_NAME) {
                        console.log('Service Worker: Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
    
    // Claim control of all clients
    self.clients.claim();
});

// Fetch event - serve cached content when offline
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);
    
    // Handle API requests
    if (url.pathname.startsWith('/api/')) {
        event.respondWith(handleApiRequest(request));
        return;
    }
    
    // Handle static file requests
    event.respondWith(handleStaticRequest(request));
});

// Handle API requests with network-first strategy
async function handleApiRequest(request) {
    const url = new URL(request.url);
    
    try {
        // Try network first
        const networkResponse = await fetch(request);
        
        // Cache successful GET requests
        if (request.method === 'GET' && networkResponse.ok) {
            const cache = await caches.open(API_CACHE_NAME);
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        console.log('Service Worker: Network request failed, trying cache:', url.pathname);
        
        // If network fails, try cache for GET requests
        if (request.method === 'GET') {
            const cachedResponse = await caches.match(request);
            if (cachedResponse) {
                return cachedResponse;
            }
        }
        
        // Handle offline POST requests (transactions, etc.)
        if (request.method === 'POST') {
            return handleOfflinePost(request);
        }
        
        // Return offline page or error response
        return new Response(
            JSON.stringify({
                success: false,
                error: 'Network unavailable and no cached data found',
                offline: true
            }),
            {
                status: 503,
                statusText: 'Service Unavailable',
                headers: { 'Content-Type': 'application/json' }
            }
        );
    }
}

// Handle static file requests with cache-first strategy
async function handleStaticRequest(request) {
    try {
        // Try cache first
        const cachedResponse = await caches.match(request);
        if (cachedResponse) {
            return cachedResponse;
        }
        
        // If not in cache, try network
        const networkResponse = await fetch(request);
        
        // Cache the response for future use
        if (networkResponse.ok) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        console.log('Service Worker: Failed to fetch:', request.url);
        
        // Return offline fallback
        if (request.destination === 'document') {
            return caches.match('/mobile-app/index.html');
        }
        
        // Return empty response for other resources
        return new Response('', {
            status: 404,
            statusText: 'Not Found'
        });
    }
}

// Handle offline POST requests
async function handleOfflinePost(request) {
    try {
        const requestData = await request.json();
        
        // Store offline transaction
        if (request.url.includes('/api/transactions')) {
            await storeOfflineTransaction(requestData);
            
            return new Response(
                JSON.stringify({
                    success: true,
                    message: 'Transaction saved offline',
                    offline: true,
                    id: Date.now() // Temporary ID
                }),
                {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                }
            );
        }
        
        // For other POST requests, return error
        return new Response(
            JSON.stringify({
                success: false,
                error: 'Cannot process this request offline',
                offline: true
            }),
            {
                status: 503,
                headers: { 'Content-Type': 'application/json' }
            }
        );
    } catch (error) {
        return new Response(
            JSON.stringify({
                success: false,
                error: 'Failed to process offline request',
                offline: true
            }),
            {
                status: 500,
                headers: { 'Content-Type': 'application/json' }
            }
        );
    }
}

// Store offline transaction in IndexedDB
async function storeOfflineTransaction(transactionData) {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('POSOfflineDB', 1);
        
        request.onerror = () => reject(request.error);
        
        request.onsuccess = () => {
            const db = request.result;
            const transaction = db.transaction(['offline_transactions'], 'readwrite');
            const store = transaction.objectStore('offline_transactions');
            
            const offlineTransaction = {
                ...transactionData,
                offline_id: Date.now(),
                created_offline: new Date().toISOString(),
                synced: false
            };
            
            store.add(offlineTransaction);
            
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
        };
        
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            
            // Create offline transactions store
            if (!db.objectStoreNames.contains('offline_transactions')) {
                const store = db.createObjectStore('offline_transactions', {
                    keyPath: 'offline_id',
                    autoIncrement: true
                });
                store.createIndex('synced', 'synced', { unique: false });
            }
        };
    });
}

// Background sync for offline transactions
self.addEventListener('sync', (event) => {
    if (event.tag === 'background-sync-transactions') {
        event.waitUntil(syncOfflineTransactions());
    }
});

// Sync offline transactions when online
async function syncOfflineTransactions() {
    try {
        const db = await openIndexedDB();
        const transaction = db.transaction(['offline_transactions'], 'readwrite');
        const store = transaction.objectStore('offline_transactions');
        const index = store.index('synced');
        
        const unsyncedTransactions = await getAllFromIndex(index, false);
        
        for (const offlineTransaction of unsyncedTransactions) {
            try {
                const response = await fetch('/api/transactions', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${await getStoredToken()}`
                    },
                    body: JSON.stringify(offlineTransaction)
                });
                
                if (response.ok) {
                    // Mark as synced
                    offlineTransaction.synced = true;
                    offlineTransaction.synced_at = new Date().toISOString();
                    store.put(offlineTransaction);
                }
            } catch (error) {
                console.error('Failed to sync transaction:', error);
            }
        }
    } catch (error) {
        console.error('Background sync failed:', error);
    }
}

// Helper functions for IndexedDB
function openIndexedDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('POSOfflineDB', 1);
        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);
    });
}

function getAllFromIndex(index, value) {
    return new Promise((resolve, reject) => {
        const request = index.getAll(value);
        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);
    });
}

async function getStoredToken() {
    // This would need to be implemented to get the token from storage
    // For now, return null
    return null;
}

// Push notification handling
self.addEventListener('push', (event) => {
    if (!event.data) return;
    
    const data = event.data.json();
    const options = {
        body: data.body,
        icon: '/mobile-app/images/icon-192x192.png',
        badge: '/mobile-app/images/icon-72x72.png',
        vibrate: [100, 50, 100],
        data: data.data,
        actions: data.actions || []
    };
    
    event.waitUntil(
        self.registration.showNotification(data.title, options)
    );
});

// Notification click handling
self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    
    const urlToOpen = event.notification.data?.url || '/mobile-app/';
    
    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true })
            .then((clientList) => {
                // Check if app is already open
                for (const client of clientList) {
                    if (client.url.includes('/mobile-app/') && 'focus' in client) {
                        return client.focus();
                    }
                }
                
                // Open new window if app is not open
                if (clients.openWindow) {
                    return clients.openWindow(urlToOpen);
                }
            })
    );
});

// Message handling from main app
self.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
    
    if (event.data && event.data.type === 'GET_VERSION') {
        event.ports[0].postMessage({ version: CACHE_NAME });
    }
});

// Periodic background sync (if supported)
self.addEventListener('periodicsync', (event) => {
    if (event.tag === 'pos-data-sync') {
        event.waitUntil(syncOfflineTransactions());
    }
});

console.log('Service Worker: Loaded successfully');
